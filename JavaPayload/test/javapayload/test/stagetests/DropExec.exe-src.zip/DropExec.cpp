// DropExec.cpp : Defines the entry point for the console application.
//

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

void mainCRTStartup() {
	const char* message = "Dropped and Executed.\r\n";
	DWORD bw;
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
	WriteFile(out, message, 23, &bw, 0);
	ExitProcess(0);
}

